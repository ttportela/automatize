### Datasets

Datasets descriptions, statistics and files to download (provided with the .MAT format).

**.MAT File Format:** the .MAT File Format is specially create to represent Multiple Aspect Trajectory datasets, see the description of the format [here](pages/mat).)