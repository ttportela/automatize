### POI-F 

See [POIS](/method/POIS)