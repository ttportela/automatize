### Experimental Evaluation Tool

*Prepare the environment for performing experiments (generate scripts and folder structure)*